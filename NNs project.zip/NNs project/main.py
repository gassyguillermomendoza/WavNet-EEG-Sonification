import os
import time
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm
from models_conditional import ConditionalWaveNet
from dataset_conditional import NSynthConditionalDataset
from train_conditional import train 
import torch.nn.functional as F
import matplotlib.pyplot as plt

# Script intended for tmux use! Same as train conditional, different output dirs


def train_with_logging(model, train_loader, optimizer, criterion, device, num_epochs,
                       checkpoint_dir="/cs/cs152/shared/gmendoza/checkpoints/tmux",
                       output_dir="/cs/cs152/shared/gmendoza/checkpoints/tmux/outputs", resume_ckpt=None):
    os.makedirs(checkpoint_dir, exist_ok=True)
    os.makedirs(output_dir, exist_ok=True)


    if resume_ckpt:
        print(f"Resuming from checkpoint: {resume_ckpt}")
        model.load_state_dict(torch.load(resume_ckpt, map_location=device))

    model.train()
    losses = []

    for epoch in range(1, num_epochs + 1):
        running_loss = 0.0
        last_outputs = None  # For token histogram
        progress_bar = tqdm(train_loader, desc=f"Epoch {epoch}/{num_epochs}")

        for x, y, inst, pitch in progress_bar:
            x, y = x.to(device), y.to(device)
            inst, pitch = inst.to(device), pitch.to(device)

            with torch.no_grad():
                y_min, y_max = y.min().item(), y.max().item()
                if y_min < 0 or y_max > 255:
                    print(f"Invalid target: y.min={y_min}, y.max={y_max}")

            x = F.one_hot(x, num_classes=256).float().permute(0, 2, 1)

            optimizer.zero_grad()
            outputs = model(x, inst, pitch)
            loss = criterion(outputs.permute(0, 2, 1).reshape(-1, 256), y.reshape(-1))
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            progress_bar.set_postfix(loss=loss.item())
            last_outputs = outputs 

        epoch_loss = running_loss / len(train_loader)
        losses.append(epoch_loss)
        print(f"Epoch {epoch} Avg Loss: {epoch_loss:.4f}")

        plt.figure()
        plt.plot(losses, label="Training Loss")
        plt.xlabel("Epoch")
        plt.ylabel("Loss")
        plt.title("Loss over Epochs")
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, "loss_curve.png"))
        plt.close()

        with torch.no_grad():
            log_probs = F.log_softmax(last_outputs, dim=1)
            probs = log_probs.exp()
            entropy = -(probs * log_probs).sum(dim=1).mean().item()
            print(f"Epoch {epoch} - Average Entropy: {entropy:.2f}")

            predicted_tokens = probs.argmax(dim=1).flatten().cpu().numpy()

            plt.figure(figsize=(6, 3))
            plt.hist(predicted_tokens, bins=range(257), density=True,
                     color='skyblue', edgecolor='black')
            plt.title(f"Predicted Token Distribution (Epoch {epoch})")
            plt.xlabel("Token ID")
            plt.ylabel("Frequency")
            plt.tight_layout()
            plt.savefig(os.path.join(output_dir, f"token_dist_epoch{epoch}.png"))
            plt.close()

        ckpt_path = os.path.join(checkpoint_dir, f"cond_wavenet_epoch{epoch}.pt")
        torch.save(model.state_dict(), ckpt_path)
        print(f"Saved: {ckpt_path}")
        
if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    dataset = NSynthConditionalDataset("music_tokens_with_pitch.pt")
    loader = DataLoader(dataset, batch_size=8, shuffle=True)

    model = ConditionalWaveNet().to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

    train_with_logging(
        model=model,
        train_loader=loader,
        optimizer=optimizer,
        criterion=criterion,
        device=device,
        num_epochs=35,
        checkpoint_dir="/cs/cs152/shared/gmendoza/checkpoints/tmux",
        resume_ckpt= None
    )


