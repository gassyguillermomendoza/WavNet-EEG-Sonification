import torch
import torch.nn.functional as F
import numpy as np
from scipy.io.wavfile import write as write_wav
from models import MinimalWaveNet
from utils import dequantize_audio

# only useful for first couple of models simple-ish
# generating audio from conditional models use generate_contitioned form utils

@torch.no_grad()
def generate(model, seed_token=128, length=16000, temperature=1.0, device='cuda'):
    model.eval()
    tokens = [seed_token]

    for _ in range(length - 1):
        x = torch.tensor(tokens[-1024:], dtype=torch.long, device=device).unsqueeze(0)
        x_input = F.one_hot(x, num_classes=256).float().permute(0, 2, 1)
        logits = model(x_input)
        probs = F.softmax(logits[:, :, -1] / temperature, dim=1)
        next_token = torch.multinomial(probs, num_samples=1).item()
        tokens.append(next_token)

    return np.array(tokens, dtype=np.uint8)

if __name__ == "__main__":
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = MinimalWaveNet().to(device)
    model.load_state_dict(torch.load("wavenet_minimal.pt"))
    tokens = generate(model, length=16000)
    waveform = dequantize_audio(tokens)
    waveform = np.int16(waveform * 32767)
    write_wav("generated.wav", 16000, waveform)
    print("Saved: generated.wav")
