import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from models import MinimalWaveNet
from dataset import TokenDataset
# I think this became obsolete for later conditional models
# Filename is a misnomer
def train():
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = MinimalWaveNet().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    criterion = torch.nn.CrossEntropyLoss()

    dataset = TokenDataset('music_tokens.pt')
    loader = DataLoader(dataset, batch_size=4, shuffle=True)
    
    train_losses = []
    for epoch in range(20):
        total_loss = 0
        for x, y in loader:
            x, y = x.to(device).long(), y.to(device).long()
            x_input = F.one_hot(x, num_classes=256).float().permute(0, 2, 1)
            logits = model(x_input)
            logits = logits.permute(0, 2, 1).reshape(-1, 256)
            y = y.reshape(-1)
            loss = criterion(logits, y)
    
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
    
            total_loss += loss.item()
    
        avg_loss = total_loss / len(loader)
        train_losses.append(avg_loss)
        print(f"Epoch {epoch+1} - Loss: {avg_loss:.4f}")
    
    torch.save(model.state_dict(), 'wavenet_minimal.pt')

if __name__ == '__main__':
    train()
